<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Accueil</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
<div class="container">
<a class="navbar-brand" href="accueil.php">Magasin</a>
<div>
<a href="voirarticles.php" class="btn btn-light">Articles</a>
<a href="listeclient.php" class="btn btn-light">Clients</a>
<a href="formulairevente.php" class="btn btn-light">Vente</a>
<a href="listeventes.php" class="btn btn-light">Ventes</a>
<?php if(isset($_SESSION['user'])): ?>
<a href="deconnexion.php" class="btn btn-danger">Déconnexion</a>
<?php else: ?>
<a href="connexion.php" class="btn btn-success">Connexion</a>
<a href="inscription.php" class="btn btn-warning">Inscription</a>
<?php endif; ?>
</div>
</div>
</nav>
<div class="container mt-5">
<h1>Bienvenue sur le mini e-commerce</h1>
</div>
</body>
</html>